let cachedData = [];

// Parse the date
const parseDate = d3.timeParse("%d-%m-%y");

// Load data
d3.csv("/static/data/knmi.csv", d3.autoType).then(data => {
  data.forEach(d => {
    d.Date = parseDate(d.Date);
  });

  cachedData = data;
  drawLineChart(data);
}).catch(error => console.error("CSV load error:", error));

function drawLineChart(data) {
  const svg = d3.select("#lineChart");
  svg.selectAll("*").remove();

  const margin = { top: 20, right: 30, bottom: 50, left: 50 },
        width = svg.node().clientWidth - margin.left - margin.right,
        height = svg.node().clientHeight - margin.top - margin.bottom;

  const chart = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  // Y-axis domain is set to accommodate min-max temps
  const x = d3.scaleTime().domain(d3.extent(data, d => d.Date)).range([0, width]);
  
  // Get the overall min and max from all temperature columns
  const allTemps = data.flatMap(d => [
    d["Avg Temperature (°C)"], 
    d["Minimum Temperature (°C)"], 
    d["Maximum Temperature (°C)"]
  ]);
  const y = d3.scaleLinear()
              .domain([d3.min(allTemps) - 1, d3.max(allTemps) + 1])
              .range([height, 0]);

  
  chart.append("g").attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(x).tickFormat(d3.timeFormat("%b %d")));
  chart.append("g").call(d3.axisLeft(y));

  // Line generator
  const line = d3.line().x(d => x(d.Date));

  // Draw Average Temperature line (blue)
  chart.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", "steelblue")
    .attr("stroke-width", 2)
    .attr("d", line.y(d => y(d["Avg Temperature (°C)"])));

  // Draw Maximum Temperature line (red)
  chart.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", "red")
    .attr("stroke-width", 2)
    .attr("d", line.y(d => y(d["Maximum Temperature (°C)"])));

  // Draw Minimum Temperature line (green)
  chart.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", "green")
    .attr("stroke-width", 2)
    .attr("d", line.y(d => y(d["Minimum Temperature (°C)"])));

  // Add dots for Average Temperature
  chart.selectAll(".dot-avg")
    .data(data)
    .enter()
    .append("circle")
    .attr("class", "dot-avg")
    .attr("cx", d => x(d.Date))
    .attr("cy", d => y(d["Avg Temperature (°C)"]))
    .attr("r", 3)
    .attr("fill", "steelblue")
    .style("cursor", "pointer")
    .on("mouseover", function(event, d) {
      // Create tooltip
      const tooltip = d3.select("body").append("div")
        .attr("class", "tooltip")
        .style("position", "absolute")
        .style("background", "rgba(0,0,0,0.8)")
        .style("color", "white")
        .style("padding", "8px")
        .style("border-radius", "4px")
        .style("font-size", "12px")
        .style("pointer-events", "none")
        .style("opacity", 0);

      tooltip.transition().duration(200).style("opacity", 1);
      tooltip.html(`${d3.timeFormat("%b %d, %Y")(d.Date)}<br/>Avg: ${d["Avg Temperature (°C)"]}°C`)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", function() {
      d3.selectAll(".tooltip").remove();
    });

  // Add dots for Maximum Temperature
  chart.selectAll(".dot-max")
    .data(data)
    .enter()
    .append("circle")
    .attr("class", "dot-max")
    .attr("cx", d => x(d.Date))
    .attr("cy", d => y(d["Maximum Temperature (°C)"]))
    .attr("r", 3)
    .attr("fill", "red")
    .style("cursor", "pointer")
    .on("mouseover", function(event, d) {
      const tooltip = d3.select("body").append("div")
        .attr("class", "tooltip")
        .style("position", "absolute")
        .style("background", "rgba(0,0,0,0.8)")
        .style("color", "white")
        .style("padding", "8px")
        .style("border-radius", "4px")
        .style("font-size", "12px")
        .style("pointer-events", "none")
        .style("opacity", 0);

      tooltip.transition().duration(200).style("opacity", 1);
      tooltip.html(`${d3.timeFormat("%b %d, %Y")(d.Date)}<br/>Max: ${d["Maximum Temperature (°C)"]}°C`)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", function() {
      d3.selectAll(".tooltip").remove();
    });

  // Add dots for Minimum Temperature
  chart.selectAll(".dot-min")
    .data(data)
    .enter()
    .append("circle")
    .attr("class", "dot-min")
    .attr("cx", d => x(d.Date))
    .attr("cy", d => y(d["Minimum Temperature (°C)"]))
    .attr("r", 3)
    .attr("fill", "green")
    .style("cursor", "pointer")
    .on("mouseover", function(event, d) {
      const tooltip = d3.select("body").append("div")
        .attr("class", "tooltip")
        .style("position", "absolute")
        .style("background", "rgba(0,0,0,0.8)")
        .style("color", "white")
        .style("padding", "8px")
        .style("border-radius", "4px")
        .style("font-size", "12px")
        .style("pointer-events", "none")
        .style("opacity", 0);

      tooltip.transition().duration(200).style("opacity", 1);
      tooltip.html(`${d3.timeFormat("%b %d, %Y")(d.Date)}<br/>Min: ${d["Minimum Temperature (°C)"]}°C`)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", function() {
      d3.selectAll(".tooltip").remove();
    });
}

// Draw Bar Chart with grouped bars for all three temperatures
function drawBarChart(data) {
  const svg = d3.select("#barChart");
  svg.selectAll("*").remove();

  const margin = { top: 20, right: 30, bottom: 70, left: 50 },
        width = svg.node().clientWidth - margin.left - margin.right,
        height = svg.node().clientHeight - margin.top - margin.bottom;

  const chart = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  // Get the overall min and max from all temperature columns
  const allTemps = data.flatMap(d => [
    d["Avg Temperature (°C)"], 
    d["Minimum Temperature (°C)"], 
    d["Maximum Temperature (°C)"]
  ]);

  const x0 = d3.scaleBand()
              .domain(data.map(d => d3.timeFormat("%b %d")(d.Date)))
              .range([0, width])
              .padding(0.1);

  const x1 = d3.scaleBand()
              .domain(['min', 'avg', 'max'])
              .range([0, x0.bandwidth()])
              .padding(0.05);

  const y = d3.scaleLinear()
              .domain([d3.min(allTemps) - 1, d3.max(allTemps) + 1])
              .range([height, 0]);

  const colors = {
    'min': 'green',
    'avg': 'steelblue', 
    'max': 'red'
  };

  // Add axes
  chart.append("g").attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(x0))
        .selectAll("text")
        .attr("transform", "rotate(-45)")
        .style("text-anchor", "end");

  chart.append("g").call(d3.axisLeft(y));

  // Create groups for each date
  const dateGroups = chart.selectAll(".date-group")
    .data(data)
    .enter()
    .append("g")
    .attr("class", "date-group")
    .attr("transform", d => `translate(${x0(d3.timeFormat("%b %d")(d.Date))},0)`);

  // Add bars for each temperature type
  ['min', 'avg', 'max'].forEach(tempType => {
    const tempKey = tempType === 'avg' ? 'Avg Temperature (°C)' : 
                   tempType === 'min' ? 'Minimum Temperature (°C)' : 
                   'Maximum Temperature (°C)';
    
    dateGroups.append("rect")
      .attr("class", `bar-${tempType}`)
      .attr("x", x1(tempType))
      .attr("y", d => y(d[tempKey]))
      .attr("width", x1.bandwidth())
      .attr("height", d => height - y(d[tempKey]))
      .attr("fill", colors[tempType])
      .style("cursor", "pointer")
      .on("mouseover", function(event, d) {
        const tooltip = d3.select("body").append("div")
          .attr("class", "tooltip")
          .style("position", "absolute")
          .style("background", "rgba(0,0,0,0.8)")
          .style("color", "white")
          .style("padding", "8px")
          .style("border-radius", "4px")
          .style("font-size", "12px")
          .style("pointer-events", "none")
          .style("opacity", 0);

        tooltip.transition().duration(200).style("opacity", 1);
        tooltip.html(`${d3.timeFormat("%b %d, %Y")(d.Date)}<br/>${tempType.toUpperCase()}: ${d[tempKey]}°C`)
          .style("left", (event.pageX + 10) + "px")
          .style("top", (event.pageY - 28) + "px");
      })
      .on("mouseout", function() {
        d3.selectAll(".tooltip").remove();
      })
      .on("click", function(event, d) {
        alert(`Clicked on ${tempType.toUpperCase()} temperature for ${d3.timeFormat("%b %d, %Y")(d.Date)}: ${d[tempKey]}°C`);
      });
  });

  // Add zoom functionality
  const zoom = d3.zoom()
    .scaleExtent([1, 4])
    .on("zoom", function(event) {
      const transform = event.transform;
      
      // Apply transform to the chart group
      chart.attr("transform", 
        `translate(${margin.left + transform.x},${margin.top}) scale(${transform.k})`);
    });

  svg.call(zoom);
}

// Button-based chart toggle
document.getElementById("lineChartBtn").addEventListener("click", () => {
  document.getElementById("lineChartContainer").classList.remove("hidden");
  document.getElementById("barChartContainer").classList.add("hidden");
  document.getElementById("lineChartBtn").classList.add("active");
  document.getElementById("barChartBtn").classList.remove("active");
  drawLineChart(cachedData);
});

document.getElementById("barChartBtn").addEventListener("click", () => {
  document.getElementById("barChartContainer").classList.remove("hidden");
  document.getElementById("lineChartContainer").classList.add("hidden");
  document.getElementById("barChartBtn").classList.add("active");
  document.getElementById("lineChartBtn").classList.remove("active");
  drawBarChart(cachedData);
});

// Search functionality
document.getElementById("searchBtn").addEventListener("click", () => {
  const query = document.getElementById("searchInput").value.trim();
  const url = query ? `/filter-data?date=${query}` : "/filter-data";

  fetch(url)
    .then(res => res.json())
    .then(data => {
      if (data.length === 0) {
        alert("No data found for that date.");
        return;
      }
      
      // Process the data to parse dates
      data.forEach(d => {
        d.Date = parseDate(d.Date);
        d["Avg Temperature (°C)"] = +d["Avg Temperature (°C)"];
        d["Minimum Temperature (°C)"] = +d["Minimum Temperature (°C)"];
        d["Maximum Temperature (°C)"] = +d["Maximum Temperature (°C)"];
      });
      
      // Redraw the currently active chart
      if (!document.getElementById("lineChartContainer").classList.contains("hidden")) {
        drawLineChart(data);
      } else {
        drawBarChart(data);
      }
    })
    .catch(err => {
      console.error("Fetch error:", err);
      alert("Error fetching data. Please try again.");
    });
});

// Clear button functionality
document.getElementById("clearBtn").addEventListener("click", () => {
  document.getElementById("searchInput").value = "";
  
  // Redraw with all data
  if (!document.getElementById("lineChartContainer").classList.contains("hidden")) {
    drawLineChart(cachedData);
  } else {
    drawBarChart(cachedData);
  }
});