from flask import Flask, render_template, request, jsonify
import csv
import os

app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/visualization')
def visualization():
    return render_template("visualization.html")

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        # Handle form submission
        name = request.form.get('name')
        email = request.form.get('email')
        message = request.form.get('message')
        
        # Log the received data (in a real app, you'd save to database)
        print(f"Contact form submitted:")
        print(f"Name: {name}")
        print(f"Email: {email}")
        print(f"Message: {message}")
        
        # Return success response
        return jsonify({
            'status': 'success',
            'message': 'Thank you for your message! We will get back to you soon.'
        })
    
    # GET request - show the contact form
    return render_template("contact.html")

@app.route('/filter-data')
def filter_data():
    date_query = request.args.get("date")
    data = []

    csv_path = os.path.join("static", "data", "knmi.csv")
    try:
        with open(csv_path, newline='', encoding="utf-8") as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                if not date_query or row["Date"] == date_query:
                    data.append(row)
    except FileNotFoundError:
        return jsonify({'error': 'Data file not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)