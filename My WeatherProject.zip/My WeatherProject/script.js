let cachedData = [];

// Load data
d3.csv("data/knmi.csv", d3.autoType).then(data => {
  data.forEach(d => {
    d.Date = parseDate(d.Date);
  });

  cachedData = data;
  drawLineChart(data);
}).catch(error => console.error("CSV load error:", error));

/*Parse the data */ 
const parseDate = d3.timeParse("%d-%m-%y");

// Draw Line Chart with all three temperature lines
function drawLineChart(data) {
  const svg = d3.select("#lineChart");
  svg.selectAll("*").remove();

  const margin = { top: 20, right: 30, bottom: 50, left: 50 },
        width = svg.node().clientWidth - margin.left - margin.right,
        height = svg.node().clientHeight - margin.top - margin.bottom;

  const chart = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  /* Y-axis domain is set to accommodate min-max temps */
  const x = d3.scaleTime().domain(d3.extent(data, d => d.Date)).range([0, width]);
  
  // Get the overall min and max from all temperature columns
  const allTemps = data.flatMap(d => [
    d["Avg Temperature (°C)"], 
    d["Minimum Temperature (°C)"], 
    d["Maximum Temperature (°C)"]
  ]);
  const y = d3.scaleLinear()
              .domain([d3.min(allTemps) - 1, d3.max(allTemps) + 1])
              .range([height, 0]);

  // Add axes
  chart.append("g").attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(x).tickFormat(d3.timeFormat("%b %d")));
  chart.append("g").call(d3.axisLeft(y));

  // Line generator
  const line = d3.line().x(d => x(d.Date));

  // Draw Average Temperature line (blue)
  chart.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", "steelblue")
    .attr("stroke-width", 2)
    .attr("d", line.y(d => y(d["Avg Temperature (°C)"])));

  // Draw Maximum Temperature line (red)
  chart.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", "red")
    .attr("stroke-width", 2)
    .attr("d", line.y(d => y(d["Maximum Temperature (°C)"])));

  // Draw Minimum Temperature line (green)
  chart.append("path")
    .datum(data)
    .attr("fill", "none")
    .attr("stroke", "green")
    .attr("stroke-width", 2)
    .attr("d", line.y(d => y(d["Minimum Temperature (°C)"])));

  // Add dots for Average Temperature
  chart.selectAll(".dot-avg")
    .data(data)
    .enter()
    .append("circle")
    .attr("class", "dot-avg")
    .attr("cx", d => x(d.Date))
    .attr("cy", d => y(d["Avg Temperature (°C)"]))
    .attr("r", 3)
    .attr("fill", "steelblue")
    .append("title")
    .text(d => `${d3.timeFormat("%b %d")(d.Date)}: Avg ${d["Avg Temperature (°C)"]}°C`);

  // Add dots for Maximum Temperature
  chart.selectAll(".dot-max")
    .data(data)
    .enter()
    .append("circle")
    .attr("class", "dot-max")
    .attr("cx", d => x(d.Date))
    .attr("cy", d => y(d["Maximum Temperature (°C)"]))
    .attr("r", 3)
    .attr("fill", "red")
    .append("title")
    .text(d => `${d3.timeFormat("%b %d")(d.Date)}: Max ${d["Maximum Temperature (°C)"]}°C`);

  // Add dots for Minimum Temperature
  chart.selectAll(".dot-min")
    .data(data)
    .enter()
    .append("circle")
    .attr("class", "dot-min")
    .attr("cx", d => x(d.Date))
    .attr("cy", d => y(d["Minimum Temperature (°C)"]))
    .attr("r", 3)
    .attr("fill", "green")
    .append("title")
    .text(d => `${d3.timeFormat("%b %d")(d.Date)}: Min ${d["Minimum Temperature (°C)"]}°C`);
}

// Draw Bar Chart with grouped bars for all three temperatures
function drawBarChart(data) {
  const svg = d3.select("#barChart");
  svg.selectAll("*").remove();

  const margin = { top: 20, right: 30, bottom: 50, left: 50 },
        width = svg.node().clientWidth - margin.left - margin.right,
        height = svg.node().clientHeight - margin.top - margin.bottom;

  const chart = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  // Get the overall min and max from all temperature columns
  const allTemps = data.flatMap(d => [
    d["Avg Temperature (°C)"], 
    d["Minimum Temperature (°C)"], 
    d["Maximum Temperature (°C)"]
  ]);

  const x0 = d3.scaleBand()
              .domain(data.map(d => d3.timeFormat("%b %d")(d.Date)))
              .range([0, width])
              .padding(0.1);

  const x1 = d3.scaleBand()
              .domain(['min', 'avg', 'max'])
              .range([0, x0.bandwidth()])
              .padding(0.05);

  const y = d3.scaleLinear()
              .domain([d3.min(allTemps) - 1, d3.max(allTemps) + 1])
              .range([height, 0]);

  const colors = {
    'min': 'green',
    'avg': 'steelblue', 
    'max': 'red'
  };

  // Add axes
  chart.append("g").attr("transform", `translate(0,${height})`)
        .call(d3.axisBottom(x0))
        .selectAll("text")
        .attr("transform", "rotate(-45)")
        .style("text-anchor", "end");

  chart.append("g").call(d3.axisLeft(y));

  // Create groups for each date
  const dateGroups = chart.selectAll(".date-group")
    .data(data)
    .enter()
    .append("g")
    .attr("class", "date-group")
    .attr("transform", d => `translate(${x0(d3.timeFormat("%b %d")(d.Date))},0)`);

  // Add bars for each temperature type
  ['min', 'avg', 'max'].forEach(tempType => {
    const tempKey = tempType === 'avg' ? 'Avg Temperature (°C)' : 
                   tempType === 'min' ? 'Minimum Temperature (°C)' : 
                   'Maximum Temperature (°C)';
    
    dateGroups.append("rect")
      .attr("class", `bar-${tempType}`)
      .attr("x", x1(tempType))
      .attr("y", d => y(d[tempKey]))
      .attr("width", x1.bandwidth())
      .attr("height", d => height - y(d[tempKey]))
      .attr("fill", colors[tempType])
      .append("title")
      .text(d => `${d3.timeFormat("%b %d")(d.Date)}: ${tempType.toUpperCase()} ${d[tempKey]}°C`);
  });

  // Add this after your existing drawBarChart function
function drawZoomableBarChart(data) {
  const svg = d3.select("#barChart");
  svg.selectAll("*").remove();

  const margin = { top: 20, right: 30, bottom: 70, left: 50 },
        width = svg.node().clientWidth - margin.left - margin.right,
        height = svg.node().clientHeight - margin.top - margin.bottom;

  const chart = svg.append("g").attr("transform", `translate(${margin.left},${margin.top})`);

  // Scales
  const x = d3.scaleBand()
    .domain(data.map(d => d3.timeFormat("%b %d")(d.Date)))
    .range([0, width])
    .padding(0.1);

  const y = d3.scaleLinear()
    .domain([0, d3.max(data, d => d["Maximum Temperature (°C)"]) + 2])
    .range([height, 0]);

  // Axes
  const xAxis = chart.append("g")
    .attr("transform", `translate(0,${height})`)
    .call(d3.axisBottom(x));

  chart.append("g").call(d3.axisLeft(y));

  // Bars
  const bars = chart.selectAll(".bar")
    .data(data)
    .enter().append("rect")
    .attr("class", "bar")
    .attr("x", d => x(d3.timeFormat("%b %d")(d.Date)))
    .attr("y", d => y(d["Avg Temperature (°C)"]))
    .attr("width", x.bandwidth())
    .attr("height", d => height - y(d["Avg Temperature (°C)"]))
    .attr("fill", "steelblue");

  // Zoom behavior
  const zoom = d3.zoom()
    .scaleExtent([1, 8]) // Limit zoom scale
    .on("zoom", (event) => {
      const newX = event.transform.rescaleX(x);
      
      // Update x-axis with new scale
      xAxis.call(d3.axisBottom(newX));
      
      // Update bars with new positions and widths
      bars.attr("x", d => newX(d3.timeFormat("%b %d")(d.Date)))
          .attr("width", newX.bandwidth());
    });

  // Apply zoom to the SVG
  svg.call(zoom);

  // Add simple zoom controls
  const zoomControls = svg.append("g")
    .attr("class", "zoom-controls")
    .attr("transform", `translate(${width - 100}, 10)`);

  zoomControls.append("rect")
    .attr("width", 90)
    .attr("height", 60)
    .attr("fill", "white")
    .attr("stroke", "#ccc");

  zoomControls.append("text")
    .attr("x", 45)
    .attr("y", 20)
    .attr("text-anchor", "middle")
    .text("Zoom:");

  zoomControls.append("g")
    .attr("transform", "translate(20, 30)")
    .append("text")
    .text("Scroll to zoom")
    .attr("font-size", "10px");
}

// Update your bar chart button click handler to use the zoomable version
document.getElementById("barChartBtn").addEventListener("click", () => {
  document.getElementById("barChartContainer").classList.remove("hidden");
  document.getElementById("lineChartContainer").classList.add("hidden");
  document.getElementById("barChartBtn").classList.add("active");
  document.getElementById("lineChartBtn").classList.remove("active");
  drawZoomableBarChart(cachedData); // Use the zoomable version
});
}

// Button-based chart toggle
document.getElementById("lineChartBtn").addEventListener("click", () => {
  document.getElementById("lineChartContainer").classList.remove("hidden");
  document.getElementById("barChartContainer").classList.add("hidden");
  document.getElementById("lineChartBtn").classList.add("active");
  document.getElementById("barChartBtn").classList.remove("active");
  drawLineChart(cachedData); // Redraw to ensure it's visible
});

document.getElementById("barChartBtn").addEventListener("click", () => {
  document.getElementById("barChartContainer").classList.remove("hidden");
  document.getElementById("lineChartContainer").classList.add("hidden");
  document.getElementById("barChartBtn").classList.add("active");
  document.getElementById("lineChartBtn").classList.remove("active");
  drawBarChart(cachedData); // Draw the bar chart
});





//Data visualization //
